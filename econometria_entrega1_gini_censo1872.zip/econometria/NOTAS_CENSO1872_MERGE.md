# Notas — Censo 1872 e merge da Questão 1

O arquivo enviado pelo grupo foi colocado em `input/censo_1872.csv`.

## O que foi adaptado

1. `code/1_abre_base_q1.R`
   - Agora lê o Censo 1872 no formato real enviado: separador `;` e encoding `Latin1`.
   - O Gini 2010 continua sendo baixado diretamente pelo R via `basedosdados`, caso `input/gini_2010.csv` não exista.

2. `code/2_limpa_dados_q1.R`
   - Agora reconhece o formato bruto do Censo 1872, com as colunas:
     - `PrimeiroDeProvincia`
     - `PrimeiroDeMunicipio`
     - `Sexo_Condicao`
     - `Total_Almas`
   - Agrega a base por município histórico.
   - Calcula:
     - `pop_total`
     - `pop_escrava`
     - `share_escravos`
   - Como o arquivo não traz `id_municipio` atual, o merge com o Gini 2010 é feito por `sigla_uf + nome_norm`.

3. `output/entrega1.tex`
   - O texto da seção de merge foi atualizado para explicar que o casamento é feito por UF e nome padronizado, não por código IBGE.

## Arquivos gerados para conferir o merge

Depois de rodar `source("code/_master.R")`, o script gera:

- `output/diagnostico_merge_q1.txt`
- `output/censo1872_municipios_agregados.csv`
- `output/municipios_gini_sem_match_censo1872.csv`
- `output/municipios_censo1872_sem_match_gini.csv`
- `output/sugestoes_match_censo1872.csv`, se o pacote `stringdist` estiver disponível.

## Correções manuais opcionais

Se houver poucos municípios casados, criem uma cópia de:

`input/de_para_censo1872_municipios_EXEMPLO.csv`

com o nome:

`input/de_para_censo1872_municipios.csv`

e preencham as colunas:

```csv
sigla_uf,nome_censo,nome_atual
AL,Santa Luizia do Norte,Santa Luzia do Norte
AL,Pão D'Assucar,Pão de Açúcar
```

Depois rodem novamente o `_master.R`.
