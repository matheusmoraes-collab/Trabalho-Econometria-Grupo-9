# =============================================================================
# 5_series_q2.R — Download, organização e visualização das séries (Q2)
# Grupo: [NOME DO GRUPO] — Econometria I, IE-UFRJ, 2026.1
# Autores: [Nomes]
# Última modificação: junho/2026
#
# Objetivo: Baixar (via rbcb) ou ler (de input/) as séries de IPCA,
#           desemprego e expectativa de inflação. Agregar para frequência
#           trimestral. Plotar e salvar.
#
# Inputs:
#   (automático via rbcb) OU:
#   input/ipca_trimestral.csv        — IPCA trimestral (%)
#   input/desemprego_trimestral.csv  — Taxa de desemprego PNAD (%)
#   input/focus_trimestral.csv       — Mediana Focus 12m (%)
#
# Outputs:
#   tmp/base_q2.rds           — painel trimestral com as três séries
#   output/fig_series_q2.pdf  — gráfico das séries no tempo
# =============================================================================

cat(">> [5] Baixando/lendo séries da Q2 (Curva de Phillips)...\n")

# Período de análise
DATA_INI <- "2012-01-01"
DATA_FIM  <- "2024-12-31"

# ---- 5.1 Tenta baixar via rbcb; se falhar, lê de input/ -------------------

baixar_serie <- function(codigo, nome_arquivo_fallback, nome_var) {
  # Tenta via rbcb
  resultado <- tryCatch({
    s <- rbcb::get_series(codigo,
                          start_date = DATA_INI,
                          end_date   = DATA_FIM)
    names(s) <- c("data", nome_var)
    cat(sprintf("  [OK via rbcb] %s: %d observações\n", nome_var, nrow(s)))
    s
  }, error = function(e) {
    cat(sprintf("  [rbcb falhou] Lendo de input/%s...\n", nome_arquivo_fallback))
    caminho <- file.path(INPDIR, nome_arquivo_fallback)
    if (!file.exists(caminho)) {
      stop(sprintf(
        "Arquivo não encontrado: input/%s\n  Baixe do SGS do Banco Central (código %d).",
        nome_arquivo_fallback, codigo))
    }
    s <- read_csv(caminho, col_types = cols())
    # Espera colunas: data (Date ou character) e a variável
    if (!nome_var %in% names(s)) {
      # Se tiver só duas colunas, renomeia a segunda
      if (ncol(s) == 2) names(s) <- c("data", nome_var)
    }
    s$data <- as.Date(s$data)
    s
  })
  resultado
}

# SGS 433  = IPCA variação mensal (%)
# SGS 24369 = Desemprego PNAD Contínua trimestral (%)
# SGS 13521 = Focus: mediana expectativa IPCA 12 meses (%)

ipca_mensal   <- baixar_serie(433,   "ipca_mensal.csv",        "ipca_mensal")
desemprego_t  <- baixar_serie(24369, "desemprego_trimestral.csv", "desemprego")
focus_mensal  <- baixar_serie(13521, "focus_trimestral.csv",    "expect_inflacao")

# ---- 5.2 Agregar IPCA para trimestral (acumulado no trimestre) -------------
ipca_trim <- ipca_mensal %>%
  mutate(
    ano       = year(data),
    trimestre = quarter(data)
  ) %>%
  group_by(ano, trimestre) %>%
  # Acumulado trimestral pelo método de capitalização composta
  summarise(
    ipca = prod(1 + ipca_mensal / 100) * 100 - 100,
    .groups = "drop"
  ) %>%
  mutate(data = yq(paste0(ano, ":Q", trimestre)))

# Agregar Focus para trimestral (média do trimestre)
focus_trim <- focus_mensal %>%
  mutate(
    ano       = year(data),
    trimestre = quarter(data)
  ) %>%
  group_by(ano, trimestre) %>%
  summarise(
    expect_inflacao = mean(expect_inflacao, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(data = yq(paste0(ano, ":Q", trimestre)))

# ---- 5.3 Merge das séries trimestrais --------------------------------------

# Desemprego já é trimestral; precisa criar coluna data compatível
if (!"data" %in% names(desemprego_t)) {
  # Alguns formatos do SGS vêm com trimestre codificado diferente
  desemprego_t <- desemprego_t %>%
    mutate(data = as.Date(data))
}

desemprego_trim <- desemprego_t %>%
  mutate(
    ano       = year(data),
    trimestre = quarter(data)
  ) %>%
  group_by(ano, trimestre) %>%
  summarise(desemprego = mean(desemprego, na.rm=TRUE), .groups="drop") %>%
  mutate(data = yq(paste0(ano, ":Q", trimestre)))

# Merge
base_q2 <- ipca_trim %>%
  left_join(desemprego_trim, by = c("ano","trimestre","data")) %>%
  left_join(focus_trim,      by = c("ano","trimestre","data")) %>%
  arrange(data) %>%
  # Defasagens
  mutate(
    ipca_lag1 = lag(ipca, 1),
    ipca_lag2 = lag(ipca, 2)
  ) %>%
  filter(!is.na(ipca), !is.na(desemprego))

cat(sprintf("\nBase Q2 final: %d trimestres (%s a %s)\n",
            nrow(base_q2),
            format(min(base_q2$data), "%Y-T%q"),
            format(max(base_q2$data), "%Y-T%q")))

# ---- 5.4 Gráfico das séries -------------------------------------------------

# Formata para formato longo (ggplot2)
base_longa <- base_q2 %>%
  select(data, ipca, desemprego, expect_inflacao) %>%
  pivot_longer(-data, names_to = "serie", values_to = "valor") %>%
  mutate(serie = recode(serie,
    "ipca"            = "IPCA (% acum. trim.)",
    "desemprego"      = "Desemprego (%)",
    "expect_inflacao" = "Expectativa inflação 12m (Focus, %)"
  ))

p_series <- ggplot(base_longa, aes(x = data, y = valor, color = serie)) +
  geom_line(linewidth = 0.8) +
  facet_wrap(~serie, scales = "free_y", ncol = 1) +
  scale_color_manual(values = c("#1f77b4","#d62728","#2ca02c")) +
  scale_x_date(date_breaks = "2 years", date_labels = "%Y") +
  labs(
    title   = "Séries Macroeconômicas Trimestrais — Brasil",
    subtitle = paste0("Período: ", format(min(base_q2$data),"%Y"), " a ",
                      format(max(base_q2$data),"%Y")),
    x       = NULL,
    y       = "Valor (%)",
    caption = "Fontes: IPCA e Focus — SGS/Banco Central; Desemprego — PNAD Contínua/SGS."
  ) +
  theme_minimal(base_size = 11) +
  theme(legend.position = "none",
        strip.text = element_text(face = "bold"))

ggsave(file.path(OUTDIR, "fig_series_q2.pdf"),
       plot = p_series, width = 9, height = 7)
ggsave(file.path(OUTDIR, "fig_series_q2.png"),
       plot = p_series, width = 9, height = 7, dpi = 150)

cat("Gráfico das séries salvo em output/fig_series_q2.pdf\n")

saveRDS(base_q2, file.path(TMPDIR, "base_q2.rds"))
cat(">> [5] Concluído.\n\n")
