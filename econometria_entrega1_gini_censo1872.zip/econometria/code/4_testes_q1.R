# =============================================================================
# 4_testes_q1.R — Testes t e F (Questão 1)
# Grupo: [NOME DO GRUPO] — Econometria I, IE-UFRJ, 2026.1
# Autores: [Nomes]
# Última modificação: junho/2026
#
# Objetivo: Executar os três testes F com linearHypothesis (car) conforme
#           pedido no enunciado. Enunciar H0/H1, reportar F, p-valor e conclusão.
#
# Inputs:  tmp/modelos_q1.rds
# Outputs: output/tab_testes_q1.tex  — tabela resumo dos testes F
#          (resultados também impressos no console)
# =============================================================================

cat(">> [4] Testes t e F da Q1...\n")

mods <- readRDS(file.path(TMPDIR, "modelos_q1.rds"))
m4   <- mods$m4
media_escravos <- mods$media_escravos

# ============================================================
# TESTE F 1 — Significância conjunta das dummies regionais
# H0: d_norte = d_nordeste = d_sul = d_centro = 0
# H1: pelo menos uma dummy regional é diferente de zero
# (Equivale a: a região não tem efeito sobre o índice de Gini,
#  condicional às outras variáveis do modelo)
# Notação Rβ = q: R é (4x9), q = (0,0,0,0)'
# ============================================================

cat("\n--- TESTE F 1: Significância conjunta das dummies regionais ---\n")
cat("H0: d_norte = d_nordeste = d_sul = d_centro = 0\n")
cat("H1: pelo menos uma dummy regional != 0\n\n")

tf1 <- car::linearHypothesis(
  m4,
  c("d_norte = 0",
    "d_nordeste = 0",
    "d_sul = 0",
    "d_centro = 0")
)
print(tf1)

F1  <- tf1$F[2]
pv1 <- tf1$`Pr(>F)`[2]
cat(sprintf("\nF calculado: %.4f | p-valor: %.6f\n", F1, pv1))
cat(ifelse(pv1 < 0.05,
           "Conclusão: Rejeitamos H0 ao nível de 5%. As dummies regionais são conjuntamente significativas.\n",
           "Conclusão: Não rejeitamos H0 ao nível de 5%. Dummies regionais não são conjuntamente significativas.\n"))

# ============================================================
# TESTE F 2 — Igualdade entre regiões (duas restrições simultâneas)
# H0: d_norte = d_nordeste  E  d_sul = d_centro
# H1: pelo menos uma das igualdades não vale
# (Testa se Norte e Nordeste têm o mesmo "prêmio" regional,
#  e se Sul e Centro-Oeste também)
# Notação Rβ = q: R é (2x9), q = (0,0)'
# ============================================================

cat("\n--- TESTE F 2: Igualdade entre pares de regiões ---\n")
cat("H0: d_norte = d_nordeste  E  d_sul = d_centro\n")
cat("H1: pelo menos uma das igualdades não se sustenta\n\n")

tf2 <- car::linearHypothesis(
  m4,
  c("d_norte - d_nordeste = 0",
    "d_sul - d_centro = 0")
)
print(tf2)

F2  <- tf2$F[2]
pv2 <- tf2$`Pr(>F)`[2]
cat(sprintf("\nF calculado: %.4f | p-valor: %.6f\n", F2, pv2))
cat(ifelse(pv2 < 0.05,
           "Conclusão: Rejeitamos H0. Norte ≠ Nordeste ou Sul ≠ Centro-Oeste.\n",
           "Conclusão: Não rejeitamos H0. Pares de regiões são estatisticamente iguais.\n"))

# ============================================================
# TESTE F 3 — Forma funcional e interação (três restrições)
# H0 (3 restrições):
#   (i)  share_escravos + 2*media*share_escravos2 = 0   (derivada na média = 0)
#   (ii) escr_x_nordeste = 0
#   (iii)share_escravos2 = 0
#
# H1: pelo menos uma das três restrições não vale
#
# Interpretação de (i): a associação marginal entre share de escravos e
# índice de Gini, avaliada na média amostral, é zero.
# ============================================================

cat("\n--- TESTE F 3: Forma funcional e interação ---\n")
cat("H0:\n")
cat(sprintf("  (i)  share_escravos + 2*%.4f*share_escravos2 = 0  (derivada na média)\n", media_escravos))
cat("  (ii) escr_x_nordeste = 0\n")
cat("  (iii)share_escravos2 = 0\n")
cat("H1: pelo menos uma das restrições é violada\n\n")

# Construção da string de restrição (i) com o valor numérico da média
restricao_i <- sprintf("share_escravos + %f * share_escravos2 = 0",
                       2 * media_escravos)

tf3 <- car::linearHypothesis(
  m4,
  c(restricao_i,
    "escr_x_nordeste = 0",
    "share_escravos2 = 0")
)
print(tf3)

F3  <- tf3$F[2]
pv3 <- tf3$`Pr(>F)`[2]
cat(sprintf("\nF calculado: %.4f | p-valor: %.6f\n", F3, pv3))
cat(ifelse(pv3 < 0.05,
           "Conclusão: Rejeitamos H0. A forma funcional quadrática e/ou a interação são relevantes.\n",
           "Conclusão: Não rejeitamos H0. O modelo linear sem interação não seria rejeitado.\n"))

# ---- Resumo em LaTeX --------------------------------------------------------
resultados_testes <- data.frame(
  Teste = c(
    "F1: Dummies regionais conjuntas",
    "F2: Norte=Nordeste e Sul=C.Oeste",
    "F3: Forma funcional + interação"
  ),
  Restricoes = c(4, 2, 3),
  H0 = c(
    "d\\_norte=d\\_nordeste=d\\_sul=d\\_centro=0",
    "d\\_norte=d\\_nordeste; d\\_sul=d\\_centro",
    "Derivada na média=0; escr×NE=0; quad=0"
  ),
  F_calculado = round(c(F1, F2, F3), 4),
  p_valor     = format(c(pv1, pv2, pv3), digits=4, scientific=TRUE),
  Conclusao   = c(
    ifelse(pv1<0.05,"Rejeita H0","Não rejeita H0"),
    ifelse(pv2<0.05,"Rejeita H0","Não rejeita H0"),
    ifelse(pv3<0.05,"Rejeita H0","Não rejeita H0")
  )
)

# Tabela LaTeX manual (stargazer não aceita tabelas genéricas bem)
sink(file.path(OUTDIR, "tab_testes_q1.tex"))
cat("\\begin{table}[htbp]\n")
cat("\\centering\n")
cat("\\caption{Testes de Hipótese --- Questão 1}\n")
cat("\\label{tab:testes_q1}\n")
cat("\\small\n")
cat("\\begin{tabular}{lcccc}\n")
cat("\\hline\\hline\n")
cat("Teste & Restrições & F calculado & p-valor & Conclusão \\\\\n")
cat("\\hline\n")
for (i in 1:nrow(resultados_testes)) {
  cat(sprintf("%s & %d & %.4f & %s & %s \\\\\n",
              resultados_testes$Teste[i],
              resultados_testes$Restricoes[i],
              resultados_testes$F_calculado[i],
              resultados_testes$p_valor[i],
              resultados_testes$Conclusao[i]))
}
cat("\\hline\\hline\n")
cat("\\multicolumn{5}{l}{\\footnotesize Nível de significância: 5\\%.}\\\\\n")
cat("\\end{tabular}\n")
cat("\\end{table}\n")
sink()

cat("\nTabela de testes salva em output/tab_testes_q1.tex\n")
cat(">> [4] Concluído.\n\n")
