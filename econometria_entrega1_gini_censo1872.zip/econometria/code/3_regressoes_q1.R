# =============================================================================
# 3_regressoes_q1.R — Estatísticas descritivas, gráficos e regressões (Q1)
# Grupo: [NOME DO GRUPO] — Econometria I, IE-UFRJ, 2026.1
# Autores: [Nomes]
# Última modificação: junho/2026
#
# Objetivo: Produzir estatísticas descritivas (stargazer), scatterplot e
#           regressões da Q1 usando o índice de Gini 2010 como variável dependente.
#
# Inputs:  tmp/base_q1.rds
# Outputs:
#   output/tab_descritivas_q1.tex   — tabela de estatísticas descritivas
#   output/tab_regressoes_q1.tex    — tabela de regressões
#   output/fig_scatter_q1.pdf       — scatterplot
# =============================================================================

cat(">> [3] Estimando regressões da Q1...\n")

base <- readRDS(file.path(TMPDIR, "base_q1.rds"))

# ---- 3.1 Estatísticas descritivas -------------------------------------------
vars_desc <- base %>%
  select(indice_gini, share_escravos, dist_tordesilhas_km,
         d_norte, d_nordeste, d_sul, d_centro) %>%
  as.data.frame()

stargazer::stargazer(
  vars_desc,
  type    = "latex",
  title   = "Estatísticas Descritivas --- Questão 1",
  label   = "tab:desc_q1",
  digits  = 3,
  summary.stat = c("n", "mean", "sd", "min", "p25", "median", "p75", "max"),
  covariate.labels = c(
    "Índice de Gini (2010)",
    "Share escravizados 1872",
    "Dist. Tordesilhas (km)",
    "Dummy Norte",
    "Dummy Nordeste",
    "Dummy Sul",
    "Dummy Centro-Oeste"
  ),
  out = file.path(OUTDIR, "tab_descritivas_q1.tex")
)

cat("Tabela descritiva salva em output/tab_descritivas_q1.tex\n")

# ---- 3.2 Scatterplot --------------------------------------------------------
p_scatter <- ggplot(base, aes(x = share_escravos, y = indice_gini)) +
  geom_point(aes(color = regiao), alpha = 0.4, size = 1.2) +
  geom_smooth(method = "lm", se = TRUE, color = "black", linewidth = 0.8) +
  scale_color_brewer(palette = "Set1", name = "Região") +
  labs(
    title    = "Índice de Gini vs. Share de Escravizados em 1872",
    subtitle = "Cada ponto é um município brasileiro. Linha: MQO simples.",
    x        = "Share de escravizados na população total (1872)",
    y        = "Índice de Gini (2010)",
    caption  = "Fontes: ONU-ADH/Base dos Dados; Recenseamento 1872/UFMG."
  ) +
  theme_minimal(base_size = 11) +
  theme(legend.position = "bottom")

ggsave(file.path(OUTDIR, "fig_scatter_q1.pdf"),
       plot = p_scatter, width = 8, height = 5)
ggsave(file.path(OUTDIR, "fig_scatter_q1.png"),
       plot = p_scatter, width = 8, height = 5, dpi = 150)

cat("Scatterplot salvo em output/fig_scatter_q1.pdf\n")

# ---- 3.3 Regressões ---------------------------------------------------------

# Modelo 1: simples (só a variável histórica)
m1 <- lm(indice_gini ~ share_escravos, data = base)

# Modelo 2: com termo quadrático e controle geográfico
m2 <- lm(indice_gini ~ share_escravos + share_escravos2 +
           dist_tordesilhas_km,
         data = base)

# Modelo 3: com dummies regionais
m3 <- lm(indice_gini ~ share_escravos + share_escravos2 +
           dist_tordesilhas_km +
           d_norte + d_nordeste + d_sul + d_centro,
         data = base)

# Modelo 4 (principal): com interação escravos × Nordeste
m4 <- lm(indice_gini ~ share_escravos + share_escravos2 +
           dist_tordesilhas_km +
           d_norte + d_nordeste + d_sul + d_centro +
           escr_x_nordeste,
         data = base)

# Ponto de inflexão do termo quadrático (modelo 4)
b1 <- coef(m4)["share_escravos"]
b2 <- coef(m4)["share_escravos2"]
inflexao <- -b1 / (2 * b2)
cat(sprintf("\nPonto de inflexão (share_escravos): %.4f\n", inflexao))
cat(sprintf("Média amostral (share_escravos): %.4f\n", mean(base$share_escravos, na.rm = TRUE)))

# Tabela de regressões
stargazer::stargazer(
  m1, m2, m3, m4,
  type  = "latex",
  title = "Legados Históricos e Desigualdade Municipal: Estimativas por MQO",
  label = "tab:reg_q1",
  dep.var.labels  = "Índice de Gini (2010)",
  column.labels   = c("Simples", "+ Quadrático", "+ Regiões", "+ Interação"),
  covariate.labels = c(
    "Share escravizados (1872)",
    "Share escravizados² (1872)",
    "Dist. Tordesilhas (km)",
    "Dummy Norte",
    "Dummy Nordeste",
    "Dummy Sul",
    "Dummy Centro-Oeste",
    "Escravizados × Nordeste"
  ),
  omit.stat = c("f", "ser"),
  add.lines = list(
    c("Dummies regionais", "Não", "Não", "Sim", "Sim"),
    c("Interação hist. × região", "Não", "Não", "Não", "Sim"),
    c(sprintf("Ponto de inflexão (M4): %.4f", inflexao), rep("", 3), "")
  ),
  digits  = 4,
  notes   = paste0(
    "Notas: Estimativas por MQO. Categoria-base: Sudeste. ",
    "Os coeficientes devem ser interpretados como associações parciais, ",
    "não efeitos causais. Erros-padrão convencionais entre parênteses."
  ),
  notes.align = "l",
  out = file.path(OUTDIR, "tab_regressoes_q1.tex")
)

cat("Tabela de regressões salva em output/tab_regressoes_q1.tex\n")

# Salva os modelos para uso no script 4
saveRDS(
  list(
    m1 = m1,
    m2 = m2,
    m3 = m3,
    m4 = m4,
    inflexao = inflexao,
    media_escravos = mean(base$share_escravos, na.rm = TRUE)
  ),
  file.path(TMPDIR, "modelos_q1.rds")
)

cat(">> [3] Concluído.\n\n")
