# =============================================================================
# _master.R — Script mestre do projeto
# Grupo: [NOME DO GRUPO] — Econometria I, IE-UFRJ, 2026.1
# Autores: [Nomes dos integrantes]
# Data: junho/2026
#
# Objetivo: Orquestrar a execução de todos os scripts do projeto em ordem.
#           Para rodar o trabalho inteiro, basta executar ESTE arquivo.
#
# Inputs:  arquivos em input/ (ver README.md para instruções de download)
# Outputs: tabelas em output/, gráficos em output/
# =============================================================================

# --- 0. Pacotes ---------------------------------------------------------------
if (!require("pacman")) install.packages("pacman")

pacman::p_load(
  # Manipulação de dados
  tidyverse, dplyr, readr, readxl, lubridate, stringr, stringi, stringdist, here,
  # Dados espaciais
  geobr, sf,
  # Econometria
  lmtest, sandwich, car, stargazer, basedosdados,
  # Séries temporais
  rbcb, zoo, tseries,
  # Gráficos
  ggplot2, patchwork, scales,
  # Formatação de tabelas
  knitr, kableExtra
)

# --- 1. Caminhos --------------------------------------------------------------
# ATENÇÃO: altere ROOT para o caminho do projeto no seu computador
ROOT   <- here::here()          # detecta automaticamente se usar RProject
# ROOT <- "C:/Users/SEU_USUARIO/econometria"  # ou coloque o caminho manual

INPDIR <- file.path(ROOT, "input")
OUTDIR <- file.path(ROOT, "output")
TMPDIR <- file.path(ROOT, "tmp")
CODDIR <- file.path(ROOT, "code")

# Garante que as pastas existem
for (d in c(INPDIR, OUTDIR, TMPDIR)) {
  if (!dir.exists(d)) dir.create(d, recursive = TRUE)
}

# --- 2. Execução dos scripts --------------------------------------------------
cat("\n==============================\n")
cat(" QUESTÃO 1 — Legados históricos\n")
cat("==============================\n\n")

source(file.path(CODDIR, "1_abre_base_q1.R"))
source(file.path(CODDIR, "2_limpa_dados_q1.R"))
source(file.path(CODDIR, "3_regressoes_q1.R"))
source(file.path(CODDIR, "4_testes_q1.R"))

cat("\n==============================\n")
cat(" QUESTÃO 2 — Curva de Phillips\n")
cat("==============================\n\n")

source(file.path(CODDIR, "5_series_q2.R"))
source(file.path(CODDIR, "6_regressoes_q2.R"))

cat("\n✓ Pipeline completo. Resultados em output/\n")
