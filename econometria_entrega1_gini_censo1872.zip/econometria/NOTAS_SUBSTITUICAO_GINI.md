# Notas da substituição para Gini 2010

Foi feita a substituição da variável dependente da Questão 1: saiu `log_pib_pc`/PIB per capita e entrou `indice_gini`/índice de Gini municipal de 2010.

## Arquivos alterados

- `README.md`
  - Atualizada a pergunta de pesquisa da Q1.
  - Atualizada a base esperada para `input/gini_2010.csv`.
  - Incluída a consulta SQL do Base dos Dados enviada pelo grupo.

- `code/_master.R`
  - Adicionados os pacotes `basedosdados`, `here` e `stringr`.

- `code/1_abre_base_q1.R`
  - Substituída a leitura de `pib_municipios.csv` pela leitura/consulta de `gini_2010.csv`.
  - Incluída tentativa de download via `basedosdados::read_sql()`.

- `code/2_limpa_dados_q1.R`
  - Substituída a limpeza do PIB pela limpeza do índice de Gini.
  - O merge final agora parte da base `gini`.
  - O script agora gera `output/diagnostico_merge_q1.txt`.

- `code/3_regressoes_q1.R`
  - Estatísticas descritivas, scatterplot e regressões agora usam `indice_gini`.
  - O título da tabela foi alterado para desigualdade municipal.

- `code/4_testes_q1.R`
  - Comentários e interpretação dos testes atualizados para Gini.

- `output/entrega1.tex`
  - Toda a seção da Questão 1 foi ajustada para Gini.
  - As interpretações foram adaptadas para variável dependente em nível, não em log.

## Atenção antes de entregar

1. Rodar `basedosdados::set_billing_id("SEU-PROJETO-GCP")` antes do `_master.R`, ou salvar manualmente a base em `input/gini_2010.csv`.
2. Garantir que `input/censo_1872.csv` tem colunas compatíveis com população total e população escravizada.
3. Rodar `source("code/_master.R")`.
4. Preencher no `output/entrega1.tex` todos os campos `[VALOR]`, `[MÉDIA]`, `[MÍNIMO]`, etc., com os resultados reais.
5. Conferir a Q2, que não foi alterada nesta substituição.

Obs.: não foi possível rodar o pipeline aqui porque o ambiente não tem R/Rscript instalado e a pasta `input/` do zip original não contém as bases.
