# Trabalho de Econometria I — IE/UFRJ — 2026.1

## Grupo
- [Nome 1] — DRE: XXXXXXX
- [Nome 2] — DRE: XXXXXXX
- [Nome 3] — DRE: XXXXXXX
- [Nome 4] — DRE: XXXXXXX

**Representante do grupo:** [Nome 1]

## Perguntas de pesquisa
- **Q1:** A intensidade da escravidão em 1872 (share de escravizados na população total)
  está associada à desigualdade municipal atual, medida pelo índice de Gini de 2010?
- **Q2:** Existe uma Curva de Phillips para o Brasil? Como inflação defasada e expectativas
  alteram a relação entre desemprego e inflação?

## Bases de dados
| Questão | Base | Fonte | Arquivo em input/ |
|---------|------|--------|-------------------|
| Q1 | Índice de Gini municipal 2010 | Base dos Dados / ONU-ADH | gini_2010.csv |
| Q1 | Recenseamento 1872 (escravizados) | Base enviada pelo grupo / UFMG | censo_1872.csv |
| Q1 | Geometria municipal | geobr (pacote R) | — (baixado no código) |
| Q2 | IPCA trimestral | SGS/Banco Central | ipca_trimestral.csv |
| Q2 | Desemprego (PNAD Contínua) | SGS/Banco Central | desemprego_trimestral.csv |
| Q2 | Expectativa inflação (Focus) | SGS/Banco Central | focus_trimestral.csv |

## Ordem de execução
Basta rodar `code/_master.R` — ele chama todos os scripts na ordem correta.

Manualmente:
1. `code/1_abre_base_q1.R` — lê e inspeciona as bases da Q1
2. `code/2_limpa_dados_q1.R` — merge e limpeza da Q1
3. `code/3_regressoes_q1.R` — estatísticas descritivas, gráficos e regressões da Q1
4. `code/4_testes_q1.R` — testes t e F da Q1
5. `code/5_series_q2.R` — baixa/lê e plota as séries da Q2
6. `code/6_regressoes_q2.R` — todas as regressões e testes da Q2

## Instruções para baixar os dados
Ver seção "Como baixar os dados" no final deste README.

---

## Como baixar os dados

### Q1 — Índice de Gini municipal 2010
Opção recomendada: o script `code/1_abre_base_q1.R` tenta baixar a base automaticamente com o pacote `basedosdados` usando a consulta SQL incluída no próprio arquivo.

Antes de rodar, configure o projeto do Google Cloud:

```r
basedosdados::set_billing_id("SEU-PROJETO-GCP")
```

Alternativa manual:
1. Acesse https://basedosdados.org
2. Busque o conjunto `mundo_onu_adh`, tabela `municipio`
3. Filtre `ano = 2010`
4. Baixe o CSV com, no mínimo, as colunas `id_municipio`, `ano` e `indice_gini`
5. Salve como `input/gini_2010.csv`

A consulta usada no script é:

```sql
SELECT
  dados.ano AS ano,
  dados.id_municipio AS id_municipio,
  diretorio_id_municipio.nome AS id_municipio_nome,
  diretorio_id_municipio.sigla_uf AS sigla_uf,
  dados.indice_gini AS indice_gini
FROM `basedosdados.mundo_onu_adh.municipio` AS dados
LEFT JOIN (
  SELECT DISTINCT id_municipio, sigla_uf, nome
  FROM `basedosdados.br_bd_diretorios_brasil.municipio`
) AS diretorio_id_municipio
ON dados.id_municipio = diretorio_id_municipio.id_municipio
WHERE dados.ano = 2010
```

### Q1 — Censo 1872
O arquivo enviado pelo grupo já foi colocado em `input/censo_1872.csv`. Ele vem no formato bruto do Recenseamento de 1872, separado por ponto e vírgula, com linhas por município e por `Sexo_Condicao`:

- `PrimeiroDeProvincia`
- `PrimeiroDeMunicipio`
- `Sexo_Condicao`
- `Total_Almas`

O script `code/2_limpa_dados_q1.R` transforma esse arquivo automaticamente em base municipal, calculando:

```r
pop_total
pop_escrava
share_escravos = pop_escrava / pop_total
```

Como o arquivo não traz o código IBGE atual de 7 dígitos, o merge com o Gini 2010 é feito por `sigla_uf + nome do município padronizado`. O script gera arquivos de diagnóstico em `output/` para vocês conferirem os casamentos:

- `diagnostico_merge_q1.txt`
- `censo1872_municipios_agregados.csv`
- `municipios_gini_sem_match_censo1872.csv`
- `municipios_censo1872_sem_match_gini.csv`
- `sugestoes_match_censo1872.csv`

Se alguns nomes históricos não casarem com os nomes atuais, criem uma cópia do arquivo `input/de_para_censo1872_municipios_EXEMPLO.csv` com o nome `input/de_para_censo1872_municipios.csv` e preencham as colunas:

```csv
sigla_uf,nome_censo,nome_atual
AL,Santa Luizia do Norte,Santa Luzia do Norte
AL,Pão D'Assucar,Pão de Açúcar
```

Depois é só rodar o `_master.R` novamente.

### Q2 — Séries temporais (SGS/Banco Central)
Acesse https://www.bcb.gov.br/estatisticas/tabelaespecial e baixe:
- IPCA mensal (código SGS 433) → agregar para trimestral → `input/ipca_trimestral.csv`
- Desemprego PNAD Contínua (código SGS 24369) → `input/desemprego_trimestral.csv`
- Focus - mediana inflação 12m (código SGS 13521) → `input/focus_trimestral.csv`

Alternativamente, o script `code/5_series_q2.R` tenta baixar automaticamente
via pacote `rbcb` — se funcionar, não é necessário baixar manualmente.
